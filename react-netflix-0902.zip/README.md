Project 3주차 09-01 제출 과제 (netflix 6~7 +8~9강)

배포 도메인 주소
https://hwi-project-004.netlify.app/

깃 도메인 주소
https://github.com/Hwiwon-source/react-netflix.git
