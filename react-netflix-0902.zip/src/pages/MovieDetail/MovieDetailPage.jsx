import React from "react";
import { Container } from "react-bootstrap";

const MovieDetailPage = () => {
  return <Container>MovieDetailPage Rendering</Container>;
};

export default MovieDetailPage;
