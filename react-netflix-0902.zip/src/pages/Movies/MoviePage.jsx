import React from "react";
import { Container } from "react-bootstrap";

const MoviePage = () => {
  return <Container>MoviePage Rendering</Container>;
};

export default MoviePage;
